class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        if(head==nullptr)
        {
            return head;
        }
        ListNode* currhead=head;
        ListNode* tail=head;
        ListNode* nexthead=currhead->next;
        ListNode* peek;
        while(nexthead!=nullptr)
        {
            peek=nexthead->next;
            nexthead->next=currhead;
            tail->next=peek;
            currhead=nexthead;
            nexthead=peek;
        }
        return currhead;
    }
};