class Solution {
public:
    ListNode* mergeTwoLists(ListNode* a, ListNode* b) 
    {
        if(a == NULL)
        return b;
        if(b == NULL)
        return a;
        ListNode* start = NULL;
        ListNode* end = NULL;
        if(a->val < b->val)
        {
            start = end = a;
            a = a->next;
        }
        else
        {
            start = end = b;
            b = b->next;
        }
        while(a != NULL && b != NULL)
        {
            if(a->val < b->val)
            {
                end -> next = a;
                end = a;
                a = a -> next;
            }
            else
            {
            end -> next = b;
            end = b;
            b = b->next;
        }
    }
    if(a == NULL)
        end->next = b;
    else
        end->next = a;
    return start;
    }
};