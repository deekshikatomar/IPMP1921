class Solution {
public:
    void deleteNode(ListNode* node) 
    {
        int temp=node->val;;
        node->val=node->next->val;
        node->next->val=temp;
        ListNode* todelete=node->next;
        node->next=node->next->next;
        delete todelete;
    }
};