class Solution {
public:
    ListNode* reverseBetween(ListNode* head, int left, int right) 
    {
        ListNode *c=head, *p=nullptr, *n=nullptr, *f, *l;
        if (!head || head->next==nullptr || left==right) return head;
        int k=1;
        bool flag=false;
        while (c)
        {
            if (k==left)
            {
                f=c;
                flag=true;
            }
            if (k==right)
            {
                l=c;
                if (l) n=l->next;
                break;
            }
            k++;
            if (!flag) p=c;
            c=c->next;
        }
        if (p) p->next=nullptr;
        else (head=l);
        l->next=nullptr;
        ListNode *rememberF=f;
        ListNode *p2=nullptr;
        while (f)
        {
            ListNode *tmp=f->next;
            f->next=p2;
            p2=f;
            f=tmp;
        }
        if (p) p->next=l;
        rememberF->next=n;
        return head;
    }
};