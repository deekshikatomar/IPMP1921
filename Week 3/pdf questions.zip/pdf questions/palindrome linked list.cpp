class Solution {
public:
    bool isPalindrome(ListNode* head) {
        ListNode* slow=head;
        ListNode* fast=head;
        while(fast!=NULL && fast->next!=NULL)
        {
            slow=slow->next;
            fast=fast->next->next;
        }
        ListNode* prevptr=NULL;
        ListNode* currptr=slow;
        ListNode* nextptr;
        while(currptr!=NULL)
        {
            nextptr=currptr->next;
            currptr->next=prevptr;
            prevptr=currptr;
            currptr=nextptr;
        }
        ListNode* hfl=prevptr;
        ListNode* hfb=head;
        while(hfl!=NULL)
        {
            if(hfl->val!=hfb->val)
            {
                return false;
            }
            hfl=hfl->next;
            hfb=hfb->next;
        }
        return true;
    }
};