class Solution {
public:
    int countlength(ListNode *h)
    {
        int c=0;
        ListNode *p=h;
        while(p!=NULL)
        {
            c++;
            p=p->next;
        }
        return c;
    }
    ListNode* rotateRight(ListNode* head, int k) 
    {
        ListNode *p=head;
        ListNode *s=head;
        if(head==NULL || k==0)
             return head;
        int length=countlength(head);
        if(length<k)
          k=k%length;
        while(k!=0)
        {
            k--;
            while(p->next!=NULL)
            {
                s=p;
                p=p->next;  
            }
            p->next=head;
            s->next=NULL;
            head=p;
        }
        return head;
    }
};