class Solution {
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
        ListNode* temp = new ListNode();
        ListNode* newHead = temp;
        int preVal = 0,sum;
        while(l1 != NULL || l2 != NULL)
        {
            int firstVal = l1 != nullptr ? l1->val : 0;
            int secVal = l2 != nullptr ? l2->val : 0;
            sum = preVal + firstVal + secVal;
            if(sum > 9)
            {
                preVal = 1;
                temp->next = new ListNode(sum%10);
                temp = temp->next;
            }
            else
            {
                preVal = 0;
                temp->next = new ListNode(sum);
                temp = temp->next;
            }
            if(l1 != NULL)
                l1= l1->next;   
            if(l2 != NULL)    
                l2= l2->next;   
        }
        if(preVal == 1)
        {
            temp->next = new ListNode(1);
            temp = temp->next;
        }
        return newHead->next;
    }
};