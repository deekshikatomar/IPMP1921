class Solution {
public:
    vector<ListNode*> splitListToParts(ListNode* root, int k) {
        vector<ListNode*> list;
        ListNode *node=root;
        int size=0;
        while(node!=nullptr)
        {
            node=node->next;
            size++;
        }
        if(k>=size)
        {
            while(k>0)
            {
                node=root;
                if(node!=nullptr)
                {
                    root=root->next;
                    node->next=nullptr;
                    list.push_back(node);
                }
                else
                    list.push_back(nullptr);
                k--;
            }     
        }
        else
        {
            int c= size/k;
            int r=size%k;
            int kk=0;
            
            ListNode *end=nullptr;
            for(int i=0;i<k;i++)
            {
                if(r>0)
                   kk=1;
                else
                    kk=0;
                node=root;
                end=root;
                for(int j=1;j<c+kk;j++)
                {
                    if(end->next!=nullptr)
                        end=end->next;
                } 
                if(end->next!=nullptr)
                     root=end->next;
                end->next=nullptr;
                list.push_back(node);
                if(r>0)
                        r--;
            }
        }
        return list;
    }
};